package exemploApostilaTablePerClass;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import service.JPAUtil;
import exemploApostilaJoin.PessoaFisicaJoin;
import exemploApostilaJoin.PessoaJuridicoJoin;

public class TesteTablePerClass  {
	public static void main(String[] args) {
		
		
		
		/*PessoaFisicaTablePerClass   pessoaF = new PessoaFisicaTablePerClass();
		PessoaJuridicaTablePerClass pessoaJ = new PessoaJuridicaTablePerClass();
		
		
		 pessoaF.setNome("Maria dos santos");
		 pessoaF.setCPF("456.456.894-X");
		 pessoaF.setEndereco("Rua da pessoa fisica nº123");
		 
		 pessoaJ.setNome("Empresa da MARIA");
		 pessoaJ.setCNPJ("859/000001");
		 pessoaJ.setEndereco("rua da pessoa juridica nº456");
		 
		 
		// gravando no banco
				 EntityManagerFactory emf = Persistence.createEntityManagerFactory("contas-postgres");
				 
				 EntityManager em = emf.createEntityManager();
				 em.getTransaction().begin();
				 
				 em.persist(pessoaF);
				 em.persist(pessoaJ);
				 
				 em.getTransaction().commit();
				 em.close();  */
		
		
		
		
		        /* para fazer update PessoaFisicaTablePerClass
		         EntityManager manager = new JPAUtil().getEntityManager();
				 PessoaFisicaTablePerClass  contaUpdate = manager.find(PessoaFisicaTablePerClass.class, 20L);
		         manager.getTransaction().begin();
				 contaUpdate.setEndereco("RUA DE TESTE 123");
					manager.getTransaction().commit();
					manager.close();*/
					

			        // para fazer update PessoaFisicaTablePerClass
			         EntityManager manager = new JPAUtil().getEntityManager();
			         PessoaJuridicaTablePerClass  contaUpdate2 = manager.find(PessoaJuridicaTablePerClass.class, 21L);
			         manager.getTransaction().begin();
					 contaUpdate2.setEndereco("RUA Do juridico 123");
						manager.getTransaction().commit();
						manager.close();	
					
		
	}

}
