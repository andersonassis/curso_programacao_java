package Teste;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.com.dextra.financas.modelo.Conta;

public class TesteJPA {

	public static void main(String[] args) {

		Conta conta = new Conta();
		conta.setTitular("Anderson Luis de Assis");
		conta.setBanco("Santander");
		conta.setAgencia("045");
		conta.setNumero("123456");

		/**
		 * Usando HSQLDB
		 */

		// EntityManagerFactory emf = Persistence
		// 		.createEntityManagerFactory("contas-hsqldb");

		/**
		 * Usando PostgreSQL
		 */
		EntityManagerFactory emf = Persistence  
		 		.createEntityManagerFactory("contas-postgres"); // aqui faz a conexão com o banco

		/**
		 * Usando MySQL
		 */
		//EntityManagerFactory emf = Persistence
		//		.createEntityManagerFactory("contas-mysql");

		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();

		em.persist(conta);

		em.getTransaction().commit();
		em.close();
	}
}
