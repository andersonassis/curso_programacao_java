package br.com.dextra.financas.jpa;

import javax.persistence.EntityManager;

import br.com.dextra.financas.modelo.Conta;
import service.JPAUtil;

public class PopulaConta {
	
	public static void main(String[] args) {
		EntityManager manager = new JPAUtil().getEntityManager();
		manager.getTransaction().begin();
			
		//Conta conta1 = new Conta();
		//Conta conta2 = new Conta();
			
	/*	conta1.setBanco("001 - BANCO DO BRASIL");
		conta1.setNumero("12345678");
		conta1.setAgencia("153-1");
		conta1.setTitular("Renata assis");
		
		conta2.setBanco("002 - BANCO BRADESCO");
		conta2.setNumero("058942");
		conta2.setAgencia("251-2");
		conta2.setTitular("Francisco de assis");
		
		manager.persist(conta1);
		manager.persist(conta2);
		*/
			
		/*
		 * 
		 * 
		// Agora vamos buscar um objeto do banco e forcar um UPDATE,
				// após o update, o objeto deverá ficar no estado MANAGED!
		Conta contaUpdate = manager.find(Conta.class, 2);
		contaUpdate.setTitular("Renata de Assis");
		manager.getTransaction().commit();
		manager.close();*/
		
		
		
			
				/**
				 * 2 - Estado TRANSIENT
				 * 
				 * Podemos dizer que um objeto que foi criado mas ainda não foi 
				 * persistido pelo JPA, esta no estado de TRANSIENT.
				 * 
				 */

				/*
				Conta contaTransiente = new Conta();

				contaTransiente.setBanco("007 - BANCO DO JAMES");
				contaTransiente.setNumero("0000-7");
				contaTransiente.setAgencia("7777");
				contaTransiente.setTitular("James Bond");
				*/

				

				// Rode um select no banco e verifique se a conta do James bound foi incluida
				// Nao foi, correto, isso porque nao chamamos o metodo persist, ou seja a entidate
				// contaTransiente ainda esta no estado TRANSIENT

				// DESCOMENTE O CÓDIGO ABAIXO
				//manager.persist(contaTransiente);

				//manager.getTransaction().commit();

				// verifique novamente no banco de dados
				
				/**
				 * 3 - Estado de DETACHED
				 * 
				 * Vamos supor que queremos atualizar os dados da conta do James,
				 * mas neste caso, nós sabemos o id da conta entao, vamos criar
				 * um novo objeto para representar a conta do James.
				 */


				/*
				Conta contaJamesDetached = new Conta();

				contaJamesDetached.setId(6);
				contaJamesDetached.setBanco("007 - BANCO DO JAMES");
				contaJamesDetached.setNumero("0000-7");
				contaJamesDetached.setAgencia("00007");
				contaJamesDetached.setTitular("James Bond Merged");
				*/
				
				
				// Neste caso, teremos que utilizar o metodo MERGE, sendo assim
				// nossa entidade passará do estado de DETACHED para MANAGED!

				//manager.getTransaction().begin();
				//contaJamesDetached = manager.merge(contaJamesDetached);
				//manager.getTransaction().commit();
				

				/**
				 * 4 - Estado de REMOVED
				 * 
				 * Bom, como próprio nome já diz, vamos remover um registro do banco!
				 */
		
				Conta contaJamesDetached = new Conta();
				//manager.getTransaction().begin();
				//manager.remove(contaJamesDetached);

				// O que acontece aqui?? para nossa infelicidade, recebemos uma exception:
				// java.lang.IllegalArgumentException: Removing a detached instance br.com.dextra.financas.modelo.Conta#56
				// isso acontece porque o objeto contaJamesDetached já esta desatachado, entao temos que recuperar o objeto
				// do banco de dados primeiro.

				// DESCOMENTE O CODIDO ABAIXO
				
				contaJamesDetached = manager.find(Conta.class, 6);
				manager.remove(contaJamesDetached);
				manager.getTransaction().commit();

				// Repare na console que um delete foi executado!!

				// ISSO É LINDO NAO??? JPA É O BIXO!!!!
				manager.close();
				
	}//fim main

}
