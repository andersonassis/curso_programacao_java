package exemploApostila;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TesteApostila {
	
	public static void main(String[] args) {
		
	
		PessoaFisica   pessoaF = new PessoaFisica();
		PessoaJuridica pessoaJ = new PessoaJuridica();
		
		 pessoaF.setNome("Marcio");
		 pessoaF.setCPF("123456789");
		 
		 pessoaJ.setNome("Empresa do Marcio");
		 pessoaJ.setCNPJ("987654489");
		 
		 
		 
		 
		 
		// gravando no banco
		 EntityManagerFactory emf = Persistence.createEntityManagerFactory("contas-postgres");
		 
		 EntityManager em = emf.createEntityManager();
		 em.getTransaction().begin();
		 
		 em.persist(pessoaF);
		 em.persist(pessoaJ);
		 
		 em.getTransaction().commit();
		 em.close();
		
		
		
	}

}
